package service;

import model.AccountType;
import model.BankAccount;
import model.SavingsAccount;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class BankService {
    private final Map<Long, BankAccount> accounts = new HashMap<>();



    public Long createAccount(String name, Double initialBalance, AccountType type) {
        BankAccount account =  new SavingsAccount(name, initialBalance);
        accounts.put(account.getAccountId(), account);
        return account.getAccountId();
    }

    public boolean deposit(Long accountId, Double amount) {
        return Optional.ofNullable(accounts.get(accountId))
                .map(acc -> {
                    depositCheck(amount,acc);
                    return true;
                }).orElse(false);
    }

    private void depositCheck(Double amount, BankAccount account) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive.");
        }
        account.setBalance(account.getBalance()+amount);



    }

    public boolean withdraw(Long accountId, double amount) {
        return Optional.ofNullable(accounts.get(accountId))
                .map(acc -> withdrawCheck(amount,acc))
                .orElse(false);
    }

    private boolean withdrawCheck(double amount, BankAccount account) {
        if (amount <= 0 || amount > account.getBalance()) return false;
        account.setBalance(account.getBalance()-amount);
        return true;
    }


    public Optional<Double> applyInterest(Long accountId) {
        BankAccount acc = accounts.get(accountId);
        if (acc instanceof SavingsAccount savings) {
            double interest = savings.calculateMonthlyInterest();
            savings.applyInterest();
            return Optional.of(interest);
        }
        return Optional.empty();
    }

    public Optional<Double> getBalance(Long accountId) {
        return Optional.ofNullable(accounts.get(accountId)).map(BankAccount::getBalance);
    }

}
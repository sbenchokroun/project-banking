package test.model;

import model.SavingsAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SavingsAccountTest {

    private SavingsAccount account;

    @BeforeEach
    void setUp() {
        account = new SavingsAccount("Alice", 2000.0);
    }

    @Test
    void testValidWithdrawal() {
        assertTrue(account.withdraw(800));
        assertEquals(1200.0, account.getBalance());
    }

    @Test
    void testExceedMaxWithdrawal() {
        assertFalse(account.withdraw(1500));
        assertEquals(2000.0, account.getBalance());
    }

    @Test
    void testExceedBalance() {
        assertFalse(account.withdraw(2500));
        assertEquals(2000.0, account.getBalance());
    }

    @Test
    void testInterestCalculation() {
        double expectedInterest = 25.0 / 3;
        double initialBalance = 2000.0;
        double interest = account.calculateMonthlyInterest();
        assertEquals( expectedInterest, interest);
        account.applyInterest();
        assertEquals(expectedInterest+initialBalance, account.getBalance());
    }
}

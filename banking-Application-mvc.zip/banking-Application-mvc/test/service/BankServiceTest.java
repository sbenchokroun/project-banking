package test.service;


import model.AccountType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import service.BankService;


import static org.junit.jupiter.api.Assertions.*;

class BankServiceTest {

    private BankService service;

    @BeforeEach
    void setUp() {
        service = new BankService();
    }


    @Test
    void testDepositAndWithdraw() {
        Long id = service.createAccount("Bob", 500.0, AccountType.CHECKING);
        assertTrue(service.deposit(id, 200.0));
        assertTrue(service.withdraw(id, 300.0));
        assertEquals(400.0, service.getBalance(id).orElse(0.0));
    }

    @Test
    void testWithdrawTooMuchFromChecking() {
        Long id = service.createAccount("Charlie", 100.0, AccountType.CHECKING);
        assertFalse(service.withdraw(id, 200.0));
    }
}

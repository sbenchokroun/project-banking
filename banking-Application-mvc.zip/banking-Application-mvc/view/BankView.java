package view;

import model.AccountType;
import service.BankService;

import java.util.Scanner;

public class BankView {
    private final BankService service = new BankService();
    private final Scanner scanner = new Scanner(System.in);


    public void run() {
        boolean running = true;

        while (running) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> createAccount();
                case 2 -> deposit();
                case 3 -> withdraw();
                case 4 -> displayBalance();
                case 5 -> calculateInterest();
                case 6 -> {
                    System.out.println("Goodbye!");
                    running = false;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private void showMenu() {
        System.out.println("""
            1. Create an account
            2. Deposit money
            3. Withdraw money
            4. Display balance
            5. Calculate interest for savings account
            6. Quit
            Enter your choice:""");
    }

    private void createAccount() {
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter initial balance: ");
        double balance = scanner.nextDouble();
        System.out.print("Choose account type (1 = Checking, 2 = Savings): ");
        int type = scanner.nextInt();

        AccountType accountType = (type == 1) ? AccountType.CHECKING : AccountType.SAVINGS;
        Long id = service.createAccount(name, balance, accountType);
        System.out.println(accountType + " Savings account created successfully. Account identifier: " + id);
    }

    private void deposit() {
        System.out.print("Enter account ID: ");
        Long id = scanner.nextLong();
        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        if (service.deposit(id, amount)) {
            System.out.println( amount +" euros have been deposited into your account.");
        } else {
            System.out.println("Account not found.");
        }
    }

    private void withdraw() {
        System.out.print("Enter account ID: ");
        Long id = scanner.nextLong();
        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        if (service.withdraw(id, amount)) {
            System.out.println( amount + " euros have been withdrawn from your account.");
        } else {
            System.out.println("Withdrawal failed. Check limits and balance.");
        }
    }

    private void displayBalance() {
        System.out.print("Enter account ID: ");
        Long id = scanner.nextLong();

        service.getBalance(id)
                .ifPresentOrElse(
                        balance -> System.out.println("Your balance is " + balance + " euros."),
                        () -> System.out.println("Account not found.")
                );
    }

    private void calculateInterest() {
        System.out.print("Enter account ID: ");
        Long id = scanner.nextLong();

        service.applyInterest(id)
                .ifPresentOrElse(
                        interest -> System.out.println("Interest for this month is " + interest + " euros."),
                        () -> System.out.println("Account not found or not a savings account.")
                );
    }
}
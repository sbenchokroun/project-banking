package controller;

import model.*;
import model.SavingsAccount;
import service.BankService;

import java.util.Optional;

public class BankController {

    private BankService service;


    public Long createAccount(String name, double initialBalance, AccountType type) {
        return service.createAccount(name,initialBalance,type);
    }

    public boolean deposit(Long accountId, double amount) {
        return service.deposit(accountId,amount);
    }

    public boolean withdraw(Long accountId, double amount) {
        return service.withdraw(accountId,amount);
    }



    public Optional<Double> applyInterest(Long accountId) {

        return service.applyInterest(accountId);
    }
}
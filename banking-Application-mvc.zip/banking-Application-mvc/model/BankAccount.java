package model;

public  class BankAccount {
    private  Long accountId;
    private  String holderName;
    private Double balance;
    private static long nextId = 1;

    public BankAccount(String holderName, double initialBalance) {
        this.accountId = nextId++;
        this.holderName = holderName;
        this.balance = initialBalance;
    }


    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public static long getNextId() {
        return nextId;
    }

    public static void setNextId(long nextId) {
        BankAccount.nextId = nextId;
    }
}
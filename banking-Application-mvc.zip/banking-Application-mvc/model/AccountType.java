package model;

public enum AccountType {
    CHECKING, SAVINGS
}
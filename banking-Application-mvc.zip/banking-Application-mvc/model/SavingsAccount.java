package model;

public class SavingsAccount extends BankAccount {
    private static final double INTEREST_RATE = 0.05;
    private static final double MAX_WITHDRAWAL = 1000.0;

    public SavingsAccount(String holderName, double initialBalance) {
        super(holderName, initialBalance);
    }


    public boolean withdraw(double amount) {
        if (amount <= 0 || amount > MAX_WITHDRAWAL || amount > getBalance()) return false;
        setBalance(getBalance()-amount);
        return true;
    }
    /*
    the interest rate is annual so we divide by 12
    * */
    public double calculateMonthlyInterest() {
        return getBalance() * INTEREST_RATE/12;
    }

    public void applyInterest() {
        setBalance(getBalance()+calculateMonthlyInterest());
    }
}